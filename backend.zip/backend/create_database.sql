-- Script untuk membuat database Fincy
-- Jalankan script ini di MySQL

CREATE DATABASE IF NOT EXISTS fincy CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

